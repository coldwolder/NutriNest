package dominio;

public interface RelatoriosGeraveis {
    void gerarRelatorio();
}