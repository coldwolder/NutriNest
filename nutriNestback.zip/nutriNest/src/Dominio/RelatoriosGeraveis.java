package Dominio;

public interface RelatoriosGeraveis {
    public void CriarRelatorio();

    public void mostrarRelatorio();

    public String gerarIntervancao(String mostrarIntervancao);

}
