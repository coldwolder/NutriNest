package Dominio;

public class avaliacaoComorbidade {

}
